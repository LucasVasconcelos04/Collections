/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.veiculos;

/**
 *
 * @author User
 */
public class Main {
    public static void main(String[] args) {
        // Criando o proprietário
        Proprietario proprietario = new Proprietario("João");

        // Criando 6 veículos
        Veiculo veiculo1 = new Veiculo("Carro A", 50000);
        Veiculo veiculo2 = new Veiculo("Carro B", 60000);
        Veiculo veiculo3 = new Veiculo("Carro C", 70000);
        Veiculo veiculo4 = new Veiculo("Carro D", 80000);
        Veiculo veiculo5 = new Veiculo("Carro E", 90000);
        Veiculo veiculo6 = new Veiculo("Carro F", 100000);

        // Adicionando veículos
        proprietario.addVeiculo(veiculo1);
        proprietario.addVeiculo(veiculo2);
        proprietario.addVeiculo(veiculo3);
        proprietario.addVeiculo(veiculo4);
        proprietario.addVeiculo(veiculo5);
        proprietario.addVeiculo(veiculo6);

        // Listando os veículos
        System.out.println("Veículos do proprietário:");
        proprietario.listarVeiculos();

        // Mostrando o valor total dos bens
        System.out.println("\nValor total dos bens: R$ " + proprietario.valorBens());
    }
}