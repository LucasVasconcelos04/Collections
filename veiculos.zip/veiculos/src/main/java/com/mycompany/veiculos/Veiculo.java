/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.veiculos;

/**
 *
 * @author User
 */

class Veiculo {
    private String modelo;
    private double valor;

    public Veiculo(String modelo, double valor) {
        this.modelo = modelo;
        this.valor = valor;
    }

    public String getModelo() {
        return modelo;
    }

    public double getValor() {
        return valor;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Veiculo veiculo = (Veiculo) obj;
        return modelo.equals(veiculo.modelo);
    }

    @Override
    public int hashCode() {
        return modelo.hashCode();
    }

    @Override
    public String toString() {
        return "Veiculo: " + modelo + ", Valor: " + valor;
    }
}

