/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.veiculos;

import java.util.HashSet;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
class Proprietario {
    private String nome;
    private HashSet<Veiculo> veiculos;

    public Proprietario(String nome) {
        this.nome = nome;
        this.veiculos = new HashSet<>();
    }

    // Método para adicionar veículo
    public void addVeiculo(Veiculo veiculo) {
        if (veiculos.size() < 5) {
            veiculos.add(veiculo);
        } else {
            int resposta = JOptionPane.showConfirmDialog(null, "Você já possui 5 veículos. Deseja adicionar mais?");
            if (resposta == JOptionPane.YES_OPTION) {
                veiculos.add(veiculo);
            }
        }
    }

    // Método para calcular o valor total dos veículos
    public double valorBens() {
        double total = 0;
        for (Veiculo v : veiculos) {
            total += v.getValor();
        }
        return total;
    }

    // Método para remover um veículo
    public void removeVeiculo(Veiculo veiculo) {
        veiculos.remove(veiculo);
    }

    // Método para listar os veículos
    public void listarVeiculos() {
        veiculos.forEach(v -> System.out.println(v));
    }
}
